---
description: Artwork for the Battery Data Alliance project
title: Battery Data Alliance
level: Sandbox Projects
featured_image: horizontal/color/BatteryDataAlliance-horizontal-color.svg
layout: logos
---